# Replication files for "Partners in crime? Corruption as a criminal network"


## File structure

- `./README.md`: the file you are currently reading
- `./replication.R`: replication script
- `./functions.R`: functions used by the replication script
- `./codebook.pdf`: data dictionary
- `./census_1.csv`: This dataset contains data from the 2014 census at the parish level for all of Uganda [Uganda Bureau of Statistics. Republic of Uganda National Population and Housing Census 2014. Uganda Bureau of Statistics (distributor). 2014].	
- `./census_2.csv`: This dataset contains data aggregated at the parish level from the electoral roster for the Arua province. To prevent identifying the sampled villages, parish identifiers have been removed. Constructed from [Republic of Uganda. National Voter's Register, Arua District. 2016]	
- `./micro_census.csv`: This dataset contains micro-level census data from the 2014 census [Uganda Bureau of Statistics. Republic of Uganda National Population and Housing Census 2014. Uganda Bureau of Statistics (distributor). 2014].	
- `./nodes.csv`: This dataset contains node-level characteristics obtained from survey data. 	
- `./ties.csv`: This dataset contains the ties elicited from respondents through our survey, as well as distances between each respondents.
- `./tables/`: output folder for tables
- `./figures/`: output folder for figures

## How to use this replication file

Run the script `./replication.R`. Please make sure to set the working directory to the folder that contains this script. Note that this script uses bootstrapping procedures with many replications. To run the script faster, it is possible to disable bootstrapping. Please refer to the instructions in `./replication.R` for further details. 
